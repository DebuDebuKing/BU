﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class projectilespeed : MonoBehaviour {
    public float speed;
    public static int damage ;
    public int damagechange;

   
    void Update () {
        damage = damagechange;
        transform.Translate(Vector2.up * speed * Time.deltaTime);

    }

   


}
